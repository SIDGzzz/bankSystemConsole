package kadai.bank;

/**
 * 取引情報を管理するクラスです。
 * 入金・出金の履歴を保持します。
 *
 * @author
 * @version 1.0
 */
public class Transaction {

    /** 口座番号 */
    private int accountNumber;

    /** 取引種類（入金・出金） */
    private String type;

    /** 取引金額 */
    private int amount;

    /**
     * コンストラクタ
     *
     * @param accountNumber 口座番号
     * @param type 取引種類
     * @param amount 取引金額
     */
    public Transaction(int accountNumber, String type, int amount) {
        this.accountNumber = accountNumber;
        this.type = type;
        this.amount = amount;
    }

    /**
     * 口座番号を取得します。
     *
     * @return 口座番号
     */
    public int getAccountNumber() {
        return accountNumber;
    }

    /**
     * 口座番号を設定します。
     *
     * @param accountNumber 口座番号
     */
    public void setAccountNumber(int accountNumber) {
        this.accountNumber = accountNumber;
    }

    /**
     * 取引種類を取得します。
     *
     * @return 取引種類
     */
    public String getType() {
        return type;
    }

    /**
     * 取引種類を設定します。
     *
     * @param type 取引種類
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * 取引金額を取得します。
     *
     * @return 取引金額
     */
    public int getAmount() {
        return amount;
    }

    /**
     * 取引金額を設定します。
     *
     * @param amount 取引金額
     */
    public void setAmount(int amount) {
        this.amount = amount;
    }

    /**
     * CSV出力用の文字列を返します。
     *
     * @return CSV形式の文字列
     */
    @Override
    public String toString() {
        return accountNumber + "," + type + "," + amount;
    }
}