package kadai.bank;

import java.util.List;
import java.util.Random;
import java.util.Scanner;

/**
 * 銀行システムのコンソール操作クラス
 *
 * @author
 * @version 1.0
*/

public class BankConsoleOperation {
/**
 * メインメソッド。<br>
 * 銀行システムを起動し、口座開設、入金、出金、残高照会、終了の操作を提供します。
 *
 */
	public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    Random random = new Random();
    System.out.println("銀行システム起動");
// CSVから口座情報を読み込む
		List<Bank> banks = BankCsvOperation.loadAccounts();
		System.out.println("口座を登録しますか？");
		System.out.println("1. はい");
		System.out.println("2. いいえ");
		System.out.print("選択してください：");

		int select = scanner.nextInt();
		scanner.nextLine();
		if (select == 1) {
    System.out.print("登録する人数を入力してください：");
    int count = scanner.nextInt();
    scanner.nextLine();

    for (int i = 0; i < count; i++) {
      System.out.println((i + 1) + "人目の口座登録");
      System.out.print("口座名義人：");
      String name = scanner.nextLine();
      System.out.print("初期残高：");
      int balance = scanner.nextInt();
      scanner.nextLine();
			int number;
 // 重複しない口座番号を生成
      while (true) {

        number = 1000000 + random.nextInt(9000000);

        boolean exists = false;

        for (Bank bank : banks) {
          if (bank.getNumber() == number) {
            exists = true;
            break;
          }
        }

        if (!exists) {
          break;
        }
      }

      banks.add(new Bank(number, name, balance));

      System.out.println("口座番号：" + number);
    }
    // CSVへ保存
    BankCsvOperation.saveAccounts(banks);
    System.out.println("口座登録が完了しました。");
	}
	while (true) {
    System.out.println();
    System.out.println("銀行システム起動");
		System.out.println("1. 入金");
    System.out.println("2. 出金");
    System.out.println("3. 残高照会");
    System.out.println("4. 終了");
    System.out.print("選択してください：");

    int menu = scanner.nextInt();
    scanner.nextLine();

		switch (menu) {
			case 1:// 入金
			System.out.print("口座番号：");
			int number = scanner.nextInt();
			System.out.print("入金額：");
			int amount = scanner.nextInt();
			scanner.nextLine();
			boolean found = false;
			for (Bank bank : banks) {
				if (bank.getNumber() == number) {
					found = true;
					if (bank.deposit(amount)) {
						BankCsvOperation.saveAccounts(banks);
						BankCsvOperation.saveTransaction(new Transaction(number, "入金", amount));
						System.out.println("入金しました。");
						System.out.println("現在の残高：" + bank.getBalance() + "円");
					} else {
						System.out.println("入金額は1円以上入力してください。");
					}
					break;
				}
			}
			if (!found) {
				System.out.println("口座番号が存在しません。");
			}
			break;

			case 2:// 出金
				System.out.print("口座番号：");
				number = scanner.nextInt();
				System.out.print("出金額：");
				amount = scanner.nextInt();
				found = false;
				for (Bank bank : banks) {
					if (bank.getNumber() == number) {
						found = true;
						if (bank.withdraw(amount)) {
							BankCsvOperation.saveAccounts(banks);
							BankCsvOperation.saveTransaction(
								new Transaction(number, "出金", amount));
								System.out.println("出金しました。");
								System.out.println("現在の残高：" + bank.getBalance() + "円");
							} else {
								System.out.println("残高不足、または金額が不正です。");
							}
							break;
						}
					}
					if (!found) {
						System.out.println("口座番号が存在しません。");
					}
					break;

				case 3:// 残高照会
					System.out.print("口座番号：");
					number = scanner.nextInt();
					scanner.nextLine();
					found = false;
					for (Bank bank : banks) {
						if (bank.getNumber() == number) {
							found = true;
							System.out.println();
							System.out.println("===== 口座情報 =====");
							System.out.println("口座番号：" + bank.getNumber());
							System.out.println("名義人：" + bank.getName());
							System.out.println("残高：" + bank.getBalance() + "円");
							System.out.println();
							System.out.println("===== 取引履歴 =====");
							List<Transaction> list =BankCsvOperation.loadTransactions(number);
							if (list.isEmpty()) {
								System.out.println("取引履歴はありません。");
							} else {
								for (Transaction t : list) {
									System.out.println(t.getType() + " : " + t.getAmount() + "円");
								}
							}
							break;
						}
					}
					if (!found) {
						System.out.println("口座番号が存在しません。");
					}
					break;
			case 4:// 終了
				System.out.println("銀行システムを終了します。");
				scanner.close();
				return;
				default:
				System.out.println("1～4の数字を入力してください。");
				break;
			}
		}
	}
}