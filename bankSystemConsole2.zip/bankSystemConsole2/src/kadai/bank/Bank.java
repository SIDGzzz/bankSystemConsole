package kadai.bank;

import java.util.ArrayList;
import java.util.List;

/**
 * 銀行口座を管理するクラスです。
 * 口座番号・口座名義・残高・取引履歴を保持します。
 *
 * @author
 * @version 1.0
 */
public class Bank {

    /** 口座番号（7桁） */
    private int number;

    /** 口座名義人 */
    private String name;

    /** 残高 */
    private int balance;

    /** 取引履歴 */
    private List<Transaction> history;

    /**
     * コンストラクタ
     *
     * @param number 口座番号
     * @param name 口座名義人
     * @param balance 初期残高
     */
    public Bank(int number, String name, int balance) {
        this.number = number;
        this.name = name;
        this.balance = balance;
        this.history = new ArrayList<>();
    }

    /**
     * 口座番号を取得します。
     *
     * @return 口座番号
     */
    public int getNumber() {
        return number;
    }

    /**
     * 口座番号を設定します。
     *
     * @param number 口座番号
     */
    public void setNumber(int number) {
        this.number = number;
    }

    /**
     * 口座名義人を取得します。
     *
     * @return 口座名義人
     */
    public String getName() {
        return name;
    }

    /**
     * 口座名義人を設定します。
     *
     * @param name 口座名義人
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * 残高を取得します。
     *
     * @return 残高
     */
    public int getBalance() {
        return balance;
    }

    /**
     * 残高を設定します。
     *
     * @param balance 残高
     */
    public void setBalance(int balance) {
        this.balance = balance;
    }

    /**
     * 取引履歴を取得します。
     *
     * @return 取引履歴
     */
    public List<Transaction> getHistory() {
        return history;
    }

    /**
     * 取引履歴を設定します。
     *
     * @param history 取引履歴
     */
    public void setHistory(List<Transaction> history) {
        this.history = history;
    }

    /**
     * 入金処理を行います。
     *
     * @param amount 入金額
     * @return 成功した場合 true
     */
    public boolean deposit(int amount) {

        if (amount <= 0) {
            return false;
        }

        balance += amount;

        history.add(new Transaction(number, "入金", amount));

        return true;
    }

    /**
     * 出金処理を行います。
     *
     * @param amount 出金額
     * @return 出金成功なら true、残高不足や金額不正なら false
     */
    public boolean withdraw(int amount) {

        if (amount <= 0) {
            return false;
        }

        if (balance < amount) {
            return false;
        }

        balance -= amount;

        history.add(new Transaction(number, "出金", amount));

        return true;
    }

    /**
     * 口座情報を文字列として返します。
     */
    @Override
    public String toString() {
        return number + "," + name + "," + balance;
    }
}