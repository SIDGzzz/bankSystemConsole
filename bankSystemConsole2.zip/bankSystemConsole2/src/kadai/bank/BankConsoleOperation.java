package kadai.bank;

import java.util.List;
import java.util.Random;
import java.util.Scanner;

/**
 * 銀行システムのコンソール操作クラス
 *
 * @author
 * @version 1.0
 */
public class BankConsoleOperation {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        System.out.println("銀行システム起動");

        // CSVから既存の口座情報を読み込む
        List<Bank> banks = BankCsvOperation.loadAccounts();
				//口座開設
        int count;
        while (true) {

            System.out.print("口座開設する人数を入力してください：");

            if (!scanner.hasNextInt()) {

                System.out.println(
                        "エラー：整数を入力してください。"
                );

                scanner.nextLine();
                continue;
            }

            count = scanner.nextInt();
            scanner.nextLine();

            if (count <= 0) {

                System.out.println("エラー：1人以上を入力してください。");
                continue;
            }
            break;
        }
        for (int i = 0; i < count; i++) {
            System.out.println();
            System.out.println("【" + (i + 1) + "人目】");

            //名前入力
            String name;
            while (true) {

                System.out.print("名前：");
                name = scanner.nextLine();

                if (name.isBlank()) {

                    System.out.println(
                            "エラー：名前を入力してください。"
                    );

                    continue;
                }

                break;
            }
						//初期残高入力
            int balance;
            while (true) {
                System.out.print("初期残高：");
                if (!scanner.hasNextInt()) {
                    System.out.println("エラー：整数を入力してください。");
                    scanner.nextLine();
                    continue;
                }
                balance = scanner.nextInt();
                scanner.nextLine();
                if (balance < 0) {
                    System.out.println("エラー：0円以上を入力してください。");
                    continue;
                }
                break;
            }
            /*
             * 7桁の口座番号を自動生成
             * 既存の口座番号と重複しないようにする
             */
            int account;
            while (true) {
                account =
                        1000000
                        + random.nextInt(9000000);
                boolean exists = false;
                for (Bank bank : banks) {
                    if (bank.getNumber() == account) {
                        exists = true;
                        break;
                    }
                }
                if (!exists) {
                    break;
                }
            }
            // 口座をリストへ追加
            banks.add(
                    new Bank(
                            account,
                            name,
                            balance
                    )
            );
            System.out.println("口座番号：" + account);
        }

        // CSVへ保存
        BankCsvOperation.saveAccounts(banks);

        System.out.println();
        System.out.println(
                "口座登録が完了しました。"
        );

        // メインメニュー
        while (true) {
            System.out.println();
            System.out.println("===== 銀行システム =====");
            System.out.println("1. 入金");
            System.out.println("2. 出金");
            System.out.println("3. 残高照会");
            System.out.println("4. 終了");

            int menu;

            while (true) {

                System.out.print("選択してください：");
                if (!scanner.hasNextInt()) {
                    System.out.println("エラー：1～4の数字を入力してください。");
                    scanner.nextLine();
                    continue;
                }
                menu = scanner.nextInt();
                scanner.nextLine();
                if (menu < 1 || menu > 4) {

                    System.out.println("エラー：1～4の数字を入力してください。");
                    continue;
                }
                break;
            }

            switch (menu) {
                //1. 入金
                case 1:
                    int number;
										// 口座番号入力
                    while (true) {
                        System.out.print("口座番号：");
                        if (!scanner.hasNextInt()) {
                            System.out.println("エラー：7桁の整数を入力してください。");
                            scanner.nextLine();
                            continue;
                        }
                        number = scanner.nextInt();
                        scanner.nextLine();
                        if (number < 1000000
                                || number > 9999999) {
                            System.out.println("エラー：7桁の口座番号を入力してください。");
                            continue;
                        }
                        break;
                    }

                    // 口座存在確認
                    Bank depositBank = null;
                    for (Bank bank : banks) {
                        if (bank.getNumber() == number) {
                            depositBank = bank;
                            break;
                        }
                    }
                    if (depositBank == null) {
                        System.out.println("エラー：口座番号が存在しません。");
                        break;
                    }

                    // 入金額入力
                    int amount;
                    while (true) {
                        System.out.print("入金額：");
                        if (!scanner.hasNextInt()) {
                            System.out.println("エラー：整数を入力してください。");
                            scanner.nextLine();
                            continue;
                        }
                        amount = scanner.nextInt();
                        scanner.nextLine();
                        if (amount <= 0) {
                            System.out.println("エラー：1円以上を入力してください。");
                            continue;
                        }
                        break;
                    }

                    if (depositBank.deposit(amount)) {
                        BankCsvOperation.saveAccounts(
                                banks
                        );
                        BankCsvOperation.saveTransaction(new Transaction(number,"入金",amount));
                        System.out.println("入金しました。");
                        System.out.println("現在の残高：" + depositBank.getBalance() + "円");
                    }
                    break;

                // 2. 出金
                case 2:
                    //口座番号入力
                    while (true) {
                        System.out.print("口座番号：");
                        if (!scanner.hasNextInt()) {
                            System.out.println("エラー：7桁の整数を入力してください。");
                            scanner.nextLine();
                            continue;
                        }
                        number = scanner.nextInt();
                        scanner.nextLine();
                        if (number < 1000000 || number > 9999999) {
                            System.out.println("エラー：7桁の口座番号を入力してください。");
                            continue;
                        }
                        break;
                    }

                    // 口座存在確認
                    Bank withdrawBank = null;
                    for (Bank bank : banks) {
                        if (bank.getNumber() == number) {
                            withdrawBank = bank;
                            break;
                        }
                    }

                    if (withdrawBank == null) {
                        System.out.println("エラー：口座番号が存在しません。");
                        break;
                    }

                    //出金額入力
                    while (true) {
                        System.out.print("出金額：");
                        if (!scanner.hasNextInt()) {
                            System.out.println("エラー：整数を入力してください。");
                            scanner.nextLine();
                            continue;
                        }
                        amount = scanner.nextInt();
                        scanner.nextLine();
                        if (amount <= 0) {
                            System.out.println("エラー：1円以上を入力してください。");
                            continue;
                        }
                        break;
                    }

                    //出金処理
                    if (withdrawBank.withdraw(amount)) {
                        BankCsvOperation.saveAccounts(banks);
                        BankCsvOperation.saveTransaction(new Transaction(number,"出金",amount));
                        System.out.println("出金しました。");
                        System.out.println("現在の残高：" + withdrawBank.getBalance() + "円");
                    } else {
                        System.out.println("エラー：残高不足です。");
                    }
										break;

                /*
                 * ==========================
                 * 3. 残高照会
                 * ==========================
                 */
                case 3:

                    while (true) {

                        System.out.print(
                                "口座番号："
                        );

                        if (!scanner.hasNextInt()) {

                            System.out.println(
                                    "エラー：7桁の整数を入力してください。"
                            );

                            scanner.nextLine();
                            continue;
                        }

                        number = scanner.nextInt();
                        scanner.nextLine();

                        if (number < 1000000
                                || number > 9999999) {

                            System.out.println(
                                    "エラー：7桁の口座番号を入力してください。"
                            );

                            continue;
                        }

                        break;
                    }

                    Bank inquiryBank = null;

                    for (Bank bank : banks) {

                        if (bank.getNumber() == number) {

                            inquiryBank = bank;
                            break;
                        }
                    }

                    if (inquiryBank == null) {

                        System.out.println(
                                "エラー：口座番号が存在しません。"
                        );

                        break;
                    }

                    System.out.println();
                    System.out.println(
                            "===== 口座情報 ====="
                    );

                    System.out.println(
                            "口座番号："
                            + inquiryBank.getNumber()
                    );

                    System.out.println(
                            "名義人："
                            + inquiryBank.getName()
                    );

                    System.out.println(
                            "残高："
                            + inquiryBank.getBalance()
                            + "円"
                    );

                    System.out.println();
                    System.out.println(
                            "===== 取引履歴 ====="
                    );

                    List<Transaction> list =
                            BankCsvOperation
                                    .loadTransactions(number);

                    if (list.isEmpty()) {

                        System.out.println(
                                "取引履歴はありません。"
                        );

                    } else {

                        for (Transaction transaction : list) {

                            System.out.println(
                                    transaction.getType()
                                    + " : "
                                    + transaction.getAmount()
                                    + "円"
                            );
                        }
                    }

                    break;

                /*
                 * ==========================
                 * 4. 終了
                 * ==========================
                 */
                case 4:

                    System.out.println(
                            "銀行システムを終了します。"
                    );

                    scanner.close();

                    return;

                default:
                    break;
            }
        }
    }
}
