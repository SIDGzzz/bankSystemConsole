package kadai.bank;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
/**
 * CSVファイルの読み込み・書き込みを行うクラスです。
 *
 * 口座情報.csv
 * 口座番号,口座名義人,残高
 *
 * 取引情報.csv
 * 口座番号,取引種類,金額
 *
 * @author
 * @version 1.0
 */
public class BankCsvOperation {
    // CSVファイル_口座情報
    private static final String ACCOUNT_FILE =
    "src/kadai/bank/File/口座情報.csv";
    // CSVファイル_取引情報
private static final String TRANSACTION_FILE =
    "src/kadai/bank/File/取引情報.csv";
    /**
     * 口座情報読み込み。
     *
     * @return 口座一覧
     */
    public static List<Bank> loadAccounts() {
        List<Bank> banks = new ArrayList<>();

        try (BufferedReader br =new BufferedReader(new FileReader(ACCOUNT_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) {
                    continue;
                }
                String[] data = line.split(",");
                int number = Integer.parseInt(data[0]);
                String name = data[1];
                int balance = Integer.parseInt(data[2]);
                banks.add(new Bank(number, name, balance));
            }
        } catch (IOException e) {
            System.out.println("口座情報CSVが存在しません。");
        }
        return banks;
    }

    //口座情報を書き込み。
    public static void saveAccounts(List<Bank> banks) {
        try (PrintWriter pw =new PrintWriter(new FileWriter(ACCOUNT_FILE))) {
            for (Bank bank : banks) {
                pw.println(bank.getNumber() + "," + bank.getName() + "," + bank.getBalance());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    // 取引履歴を追加。
    public static void saveTransaction(Transaction transaction) {
        try (PrintWriter pw =new PrintWriter(new FileWriter(TRANSACTION_FILE,true))) {
            pw.println(transaction.getAccountNumber() + "," + transaction.getType() + "," + transaction.getAmount());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //指定した口座の取引履歴を取得。
    public static List<Transaction> loadTransactions(int accountNumber) {
        List<Transaction> list = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(TRANSACTION_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) {
                    continue;
                }
                String[] data = line.split(",");
                int number = Integer.parseInt(data[0]);
                if (number != accountNumber) {
                    continue;
                }

                String type = data[1];
                int amount =Integer.parseInt(data[2]);
                list.add(new Transaction(number,type,amount));

            }

        } catch (IOException e) {

            System.out.println("取引履歴はありません。");

        }

        return list;

    }

}